#include <stdio.h>
#include "kvs.h"
int main()
{

    kvs_t* kvs = open();

    if(!kvs) {
        printf("Failed to open kvs\n");
        return -1;
    }

    // KVS created.
//    char key[100];

    char* key = (char*) malloc (sizeof(char)* 300);
    char* value = (char*) malloc (sizeof(char)* 300);
    // char key[100];
    //char value[100];
    char* rvalue;

    // kvs[100];
    node_t node[100];
    FILE *fp;
    fp=fopen("student.dat","rb"); //dat 파일 오픈
    if (fp == NULL){
        printf("파일이 존재하지 않습니다");
        return 1;
    }
//    fread(node, sizeof(node), 1, fp);
//    for (int i =0; i<5; i++){
    int i=0;
//    char *v[]={0,};
    while (!feof(fp)){ //파일이 끝날 때까지 루프를 돔
	char* tmp = malloc(sizeof(char) * 20);
	fscanf(fp,"%s %s",node[i].key,tmp); //첫 값은 키
        node[i].value=tmp;
	kvs[i].db=&node[i]; //kvs에 db는 노드의 값으로 넣어줌
        kvs->items ++; //한 번 돌때 마다 데이터 개수를 늘려줌
        kvs[i].db->next=&node[i+1]; //다음 노드값 연결
	i++;
    }

//    strcpy(key, "Eunji");
//    strcpy(value, "Seoul");

    if(put(kvs, key, value) < 0){
        printf("Failed to put data\n");
        exit(-1);
    }


    if(!(rvalue = get(kvs, key))){
        printf("Failed to get data\n");
        exit(-1);
    }

//    for(int i=0; i<kvs->items; i++){
//        key= kvs[i].db.key;
//        rvalue=kvs[i].db.value;
//        printf("get: %s, %s\n", key, rvalue);
//    }  //get함수 값을 출력해줌

    fclose(fp); //파일 닫기
    close(kvs);

    return 0;
}

