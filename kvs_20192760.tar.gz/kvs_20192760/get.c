#include "kvs.h"

char* get(kvs_t* kvs, const char* key)
{
    /* do program here */
    int count = (kvs->items)-1; //number of data
    char* value = (char*)malloc(sizeof(char)*100);

    if(!value){
        printf("Failed to malloc\n");
        return NULL;
    }
    else {
        for (int i=0; i<count; i++){ //main에서 저장해둔 kvs를 get을 통해 출력해줌
            key= kvs[i].db->key;
            value = kvs[i].db->value;
            printf("get: %s, %s\n", key, value);
        }
    }


//    strcpy(value, "deadbeaf");
    return value;

}

