#include "kvs.h"
int put(kvs_t* kvs, const char* key, const char* value)
{
    int count = (kvs->items)-1; //데이터의 개수
    for (int i=0; i<count; i++){
        printf("put: %s, %s\n", kvs[i].db->key, kvs[i].db->value); //데이터의 개수 만큼 원하는 값을 출력해줌
    }

    /* do program here */
    return 0;
}
