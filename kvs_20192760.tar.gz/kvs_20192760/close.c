#include "kvs.h"

int close(kvs_t* kvs)
{
	/* do program */
	return 0;
}
